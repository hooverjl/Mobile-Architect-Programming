package com.example.joshhoover_inventorytrackingapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "InventoryDatabase";
    private static final int DATABASE_VERSION = 1;

    // Define the table and column names for the Users table
    public static final String TABLE_USERS = "users";
    public static final String COLUMN_USER_ID = "id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";

    // Define the table and column names for the Items table
    public static final String TABLE_ITEMS = "items";
    public static final String COLUMN_ITEM_ID = "id";

    public static final String COLUMN_ITEM_NAME = "name";
    public static final String COLUMN_ITEM_NUMBER= "number";
    public static final String COLUMN_ITEM_LOCATION= "location";
    public static final String COLUMN_ITEM_QUANTITY = "quantity";

    // SQL statement to create the Users table
    private static final String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + " (" +
            COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_USERNAME + " TEXT, " +
            COLUMN_PASSWORD + " TEXT);";

    // SQL statement to create the Items table
    private static final String CREATE_ITEMS_TABLE = "CREATE TABLE " + TABLE_ITEMS + " (" +
            COLUMN_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_ITEM_NAME + " TEXT, " +
            COLUMN_ITEM_NUMBER + " TEXT, " +
            COLUMN_ITEM_LOCATION + " TEXT, " +
            COLUMN_ITEM_QUANTITY + " INTEGER);";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USERS_TABLE);
        db.execSQL(CREATE_ITEMS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Handle database upgrades if necessary
        db.execSQL("drop table if exists " + TABLE_ITEMS);
        db.execSQL("drop table if exists " + TABLE_USERS);
        onCreate(db);
    }
}
