package com.example.joshhoover_inventorytrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity3 extends AppCompatActivity {

    public static EditText editTextLowQtyAlert;
    private TextView textView3;
    public static int lowInvLevel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        editTextLowQtyAlert = findViewById(R.id.editTextLowQtyAlert);
        textView3 = findViewById(R.id.textView3);

        Button buttonInventory = findViewById(R.id.buttonInventory);
        buttonInventory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Create an intent to navigate to the second activity
                Intent intent = new Intent(MainActivity3.this, MainActivity2.class);
                startActivity(intent);
            }
        });

        Button buttonLogOut2 = findViewById(R.id.buttonLogOut2);
        buttonLogOut2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Create an intent to navigate to the second activity
                Intent intent = new Intent(MainActivity3.this, MainActivity.class);
                startActivity(intent);
            }
        });

        Button saveButton = findViewById(R.id.saveButton);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textView3.setText(editTextLowQtyAlert.getText());
                String lowInvStr = textView3.getText().toString();
                lowInvLevel = Integer.parseInt(lowInvStr);
                // Create an intent to navigate to the second activity
                Intent intent = new Intent(MainActivity3.this, MainActivity2.class);
                startActivity(intent);
            }
        });

    }
}