package com.example.joshhoover_inventorytrackingapp;

import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private EditText userNameEditText;
    private EditText passwordEditText;
    private TextView textViewMessage;
    private Button buttonCreateAccount;

    private static final int SMS_PERMISSION_REQUEST = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);
        userNameEditText = findViewById(R.id.userNameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        textViewMessage = findViewById(R.id.textLoginMessage);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);


        if (checkPermission()) {
            // app has permission
            activateSMSMessaging();
        } else {
            requestPermission();
        }



        buttonCreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = userNameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                if (!username.isEmpty() && !password.isEmpty()) {
                    registerUser(username, password);
                    // create an intent to navigate to the second activity
                    Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "Empty Field. Enter Username and Password", Toast.LENGTH_SHORT).show();
                }
            }
        });

        Button buttonLogin = findViewById(R.id.buttonLogin);
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = userNameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                if (!username.isEmpty() && !password.isEmpty()) {
                    // check if the username and password exist in the database
                    if (userExists(username, password)) {
                        // user exists, navigate to MainActivity2
                        Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                        startActivity(intent);
                    } else {
                        // user does not exist, show the "buttonCreateAccount"
                        buttonCreateAccount.setVisibility(View.VISIBLE);
                        textViewMessage.setVisibility(View.VISIBLE);
                        textViewMessage.setText("User does not exist. Click Create Account to add user.");
                    }
                } else {
                    // display the message if either field is empty
                    textViewMessage.setVisibility(View.VISIBLE);
                    textViewMessage.setText("Empty Field. Enter Username and Password");
                }
            }
        });
    }

    private boolean userExists(String username, String password) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(DatabaseHelper.TABLE_USERS,
                new String[]{DatabaseHelper.COLUMN_USER_ID},
                DatabaseHelper.COLUMN_USERNAME + " = ? AND " + DatabaseHelper.COLUMN_PASSWORD + " = ?",
                new String[]{username, password},
                null, null, null);
        boolean exists = cursor.moveToFirst();
        cursor.close();
        return exists;
    }

    private void registerUser(String username, String password) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_USERNAME, username);
        values.put(DatabaseHelper.COLUMN_PASSWORD, password);

        long newRowId = db.insert(DatabaseHelper.TABLE_USERS, null, values);

        if (newRowId != -1) {
            Toast.makeText(this, "User registered successfully.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Error registering user.", Toast.LENGTH_SHORT).show();
        }

        db.close();
    }

    // check if app has SMS permissions
    private boolean checkPermission() {
        int sendSMSPermission = ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS);
        int receiveSMSPermission = ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECEIVE_SMS);

        return sendSMSPermission == PackageManager.PERMISSION_GRANTED && receiveSMSPermission == PackageManager.PERMISSION_GRANTED;
    }


    // request SMS permissions
    private void requestPermission() {
        ActivityCompat.requestPermissions(this,
                new String[]{android.Manifest.permission.SEND_SMS, android.Manifest.permission.RECEIVE_SMS},
                SMS_PERMISSION_REQUEST);
    }

    // handle permission request results
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED
                    && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                // Permissions granted.
                activateSMSMessaging();
            } else {
                // Permissions denied.
                Toast.makeText(this, "SMS permissions are required to use SMS messaging.", Toast.LENGTH_LONG).show();
            }
        }
    }

    // activate SMS messaging
    private void activateSMSMessaging() {
        // send sms to inform user that messaging is active for this app
        SmsManager smsManager = SmsManager.getDefault();
        String phoneNumber = "650 555-6789";  // emulator phone number
        String message = "SMS Messaging is active for InventoryTrackingApp.";
        smsManager.sendTextMessage(phoneNumber, null, message, null, null);

    }


}
