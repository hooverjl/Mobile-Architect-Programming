package com.example.joshhoover_inventorytrackingapp;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;


public class MainActivity2 extends AppCompatActivity {


    private DatabaseHelper dbHelper3;

    // define a constant to represent the SMS permission request


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);



        // check if we have SMS permissions, if not, request permisssion.
        if (checkPermission()) {
            // app has permission
            appSMSMessaging();
        }


        // create database helper
        dbHelper3 = new DatabaseHelper(this);

        // populate tableLayout with data from db
        populateTableFromDatabase();

        Button buttonNotification = findViewById(R.id.buttonNotification);
        buttonNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // create an intent to navigate to the second activity
                Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
                startActivity(intent);
            }
        });

        Button buttonLogOut = findViewById(R.id.buttonLogOut);
        buttonLogOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // create an intent to navigate to the second activity
                Intent intent = new Intent(MainActivity2.this, MainActivity.class);
                startActivity(intent);
            }
        });

        Button buttonAddItem = findViewById(R.id.buttonAddItem);
        buttonAddItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // create an intent to navigate to the second activity
                Intent intent = new Intent(MainActivity2.this, MainActivity4.class);
                startActivity(intent);
            }
        });

        Button buttonUpdateQty = findViewById(R.id.buttonUpdateQty);
        buttonUpdateQty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // create an intent to navigate to the second activity
                Intent intent = new Intent(MainActivity2.this, MainActivity5.class);
                startActivity(intent);
            }
        });

    }


    private void populateTableFromDatabase() {
        SQLiteDatabase db = dbHelper3.getReadableDatabase();

        // define the columns you want to retrieve from the TABLE_ITEMS
        String[] columns = {"id", "name", "number", "location", "quantity"};

        Cursor cursor = db.query(DatabaseHelper.TABLE_ITEMS, columns, null, null, null, null, null);

        TableLayout tableLayout = findViewById(R.id.table_db_view);

        if (cursor.moveToFirst()) {
            do {
                TableRow row = new TableRow(this);

                // had to implement @SuppressLint to remove errors here
                @SuppressLint("Range") String column1Data = cursor.getString(cursor.getColumnIndex("id"));
                @SuppressLint("Range") String column2Data = cursor.getString(cursor.getColumnIndex("name"));
                @SuppressLint("Range") String column3Data = cursor.getString(cursor.getColumnIndex("number"));
                @SuppressLint("Range") String column4Data = cursor.getString(cursor.getColumnIndex("location"));
                @SuppressLint("Range") String column5Data = cursor.getString(cursor.getColumnIndex("quantity"));

                // create TextViews for each column and populate with data
                TextView textView1 = new TextView(this);
                textView1.setText(column1Data);
                textView1.setTextSize(16);

                TextView textView2 = new TextView(this);
                textView2.setText(column2Data);
                textView2.setTextSize(16);

                TextView textView3 = new TextView(this);
                textView3.setText(column3Data);
                textView3.setTextSize(16);

                TextView textView4 = new TextView(this);
                textView4.setText(column4Data);
                textView4.setTextSize(16);

                TextView textView5 = new TextView(this);
                textView5.setText(column5Data);
                textView5.setTextSize(16);

                Button deleteButton = new Button(this);
                deleteButton.setText("Delete Row");
                deleteButton.setTextSize(14);
                deleteButton.setBackgroundColor(Color.RED);
                deleteButton.setTextColor(Color.WHITE);

                // set deleteButton tag to the row ID
                deleteButton.setTag(column1Data);

                // set click listener for delet button
                deleteButton.setOnClickListener(new View.OnClickListener(){
                    @Override
                    public void onClick(View view) {
                        // Get row id
                        String id = (String) view.getTag();

                        // Delete row from db
                        deleteRowFromDatabase(id);

                        // Remove row from TableLayout
                        tableLayout.removeView(row);
                    }
                });

                // add the TextViews and Button to the TableRow
                row.addView(textView1);
                row.addView(textView2);
                row.addView(textView3);
                row.addView(textView4);
                row.addView(textView5);
                row.addView(deleteButton);

                // add the TableRow to the TableLayout
                tableLayout.addView(row);
            } while (cursor.moveToNext());
        }

        cursor.close();
    }

    private void deleteRowFromDatabase(String id) {
        SQLiteDatabase db = dbHelper3.getWritableDatabase();
        String whereClause = "id = ?";
        String[] whereArgs = {id};
        db.delete(DatabaseHelper.TABLE_ITEMS, whereClause, whereArgs);
        db.close();
    }



    // check if app has SMS permissions
    private boolean checkPermission() {
        int sendSMSPermission = ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS);
        int receiveSMSPermission = ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECEIVE_SMS);

        return sendSMSPermission == PackageManager.PERMISSION_GRANTED && receiveSMSPermission == PackageManager.PERMISSION_GRANTED;
    }


    // SMS low inventory alert
    private void appSMSMessaging() {
        if (MainActivity5.issueQtyAlarm) {
            SmsManager smsManager = SmsManager.getDefault();
            String phoneNumber = "650 555-6789";  // emulator phone number
            String message = "Item Number " + MainActivity5.itemNumber + " Low Inventory Alert!!!";
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
        }
    }


}