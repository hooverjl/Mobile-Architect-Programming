package com.example.joshhoover_inventorytrackingapp;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity5 extends AppCompatActivity {

    private DatabaseHelper dbHelper4;
    private EditText editTextItemNum2;
    private EditText editTextItemQty2;
    private TextView textViewMessage3;

    public static boolean issueQtyAlarm;
    public static String itemNumber;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);

        dbHelper4 = new DatabaseHelper(this);
        editTextItemNum2 = findViewById(R.id.editTextItemNum2);
        editTextItemQty2 = findViewById(R.id.editTextItemQty2);
        textViewMessage3 = findViewById(R.id.textViewMessage3);

        Button buttonSaveData2 = findViewById(R.id.buttonSaveData2);
        buttonSaveData2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                updateData();
            }
        });

        Button buttonInventory3 = findViewById(R.id.buttonInventory3);
        buttonInventory3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // create an intent to navigate to the second activity
                Intent intent = new Intent(MainActivity5.this, MainActivity2.class);
                startActivity(intent);
            }
        });
    }

    private void updateData() {
        String itemNum = editTextItemNum2.getText().toString().trim();
        String itemQty = editTextItemQty2.getText().toString().trim();

        if (itemNum.isEmpty() || itemQty.isEmpty()) {
            // display a message if either of the two fields is empty
            textViewMessage3.setText("Empty field, enter all data.");
            return;
        }

        // check if the itemNum exists in the SQLite database
        if (itemExistsInDatabase(itemNum)) {
            // Item exists, update its quantity
            updateQuantityInDatabase(itemNum, itemQty);

            // create an intent to navigate to the second activity
            Intent intent = new Intent(MainActivity5.this, MainActivity2.class);
            startActivity(intent);

        } else {
            // item not found, display a message
            textViewMessage3.setText("Item not found. Enter a different number.");
        }
    }

    // check if the itemNum exists in the SQLite database
    private boolean itemExistsInDatabase(String itemNum) {
        SQLiteDatabase db = dbHelper4.getReadableDatabase();
        Cursor cursor = db.query(DatabaseHelper.TABLE_ITEMS,
                new String[]{DatabaseHelper.COLUMN_USER_ID},
                DatabaseHelper.COLUMN_ITEM_NUMBER + " = ? ",
                new String[]{itemNum},
                null, null, null);
        boolean exists = cursor.moveToFirst();
        cursor.close();
        return exists;
    }

    private void updateQuantityInDatabase(String itemNum, String itemQty) {
        // get a writable database from your dbHelper3
        SQLiteDatabase db = dbHelper4.getWritableDatabase();

        // define the table name and the column names
        String tableName = DatabaseHelper.TABLE_ITEMS;
        String quantityColumn = "quantity";

        // create ContentValues to hold the new quantity value
        ContentValues values = new ContentValues();
        values.put(quantityColumn, itemQty);

        // define the WHERE clause to update the row with the specified itemNum
        String whereClause = "number = ?";
        String[] whereArgs = {itemNum};

        // execute the update statement
        int numRowsUpdated = db.update(tableName, values, whereClause, whereArgs);

        // check if any rows were updated
        if (numRowsUpdated > 0) {
            showToast("Quantity updated successfully!");
        } else {
            showToast("Error, no rows updated");
        }

        int currentQty = Integer.parseInt(itemQty);
        int alarmLimit = MainActivity3.lowInvLevel;
        if (currentQty <= alarmLimit) {
            issueQtyAlarm = true;
            itemNumber = itemNum;
        }
        db.close();
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
