package com.example.joshhoover_inventorytrackingapp;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity4 extends AppCompatActivity {

    private DatabaseHelper dbHelper2;
    private EditText editTextItemName;
    private EditText editTextItemNum;
    private EditText editTextItemLocation;
    private EditText editTextItemQty;
    private TextView textViewMessage2;
    private Button buttonSaveData;
    private Button buttonInventory2;

    public static boolean itemAdded;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        dbHelper2 = new DatabaseHelper(this);
        editTextItemName = findViewById(R.id.editTextItemName);
        editTextItemNum = findViewById(R.id.editTextItemNum);
        editTextItemLocation = findViewById(R.id.editTextItemLocation);
        editTextItemQty = findViewById(R.id.editTextItemQty);
        textViewMessage2 = findViewById(R.id.textViewMessage2);
        buttonSaveData = findViewById(R.id.buttonSaveData);
        buttonInventory2 = findViewById(R.id.buttonInventory2);

        buttonSaveData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String itemName = editTextItemName.getText().toString();
                String itemNum = editTextItemNum.getText().toString();
                String itemLoc = editTextItemLocation.getText().toString();
                String itemQty = editTextItemQty.getText().toString();

                if (!itemName.isEmpty() && !itemNum.isEmpty() && !itemLoc.isEmpty() && !itemQty.isEmpty()) {
                    // check if the username and password exist in the database
                    if (itemExists(itemName, itemNum, itemLoc, itemQty)) {
                        // item exists, enter new data
                        textViewMessage2.setText("Item information already exists. Try entering information again.");

                    } else {
                        // item does not exist, add item to DB and navigate to the second activity
                        registerItem(itemName, itemNum, itemLoc, itemQty);
                        Intent intent = new Intent(MainActivity4.this, MainActivity2.class);
                        startActivity(intent);
                    }
                } else {
                    // display message if either field is empty
                    textViewMessage2.setVisibility(View.VISIBLE);
                    textViewMessage2.setText("Empty Field. Enter all Item Information");
                }
            }
        });


        buttonInventory2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // create an intent to navigate to the second activity
                Intent intent = new Intent(MainActivity4.this, MainActivity2.class);
                startActivity(intent);
            }
        });
    }

    private boolean itemExists(String itemName, String itemNum, String itemLoc, String itemQty) {
        SQLiteDatabase db = dbHelper2.getReadableDatabase();

        Cursor cursor = db.query(DatabaseHelper.TABLE_ITEMS,
                new String[]{DatabaseHelper.COLUMN_ITEM_ID},
                DatabaseHelper.COLUMN_ITEM_NAME + " = ? AND " +
                        DatabaseHelper.COLUMN_ITEM_NUMBER + " = ? AND " +
                        DatabaseHelper.COLUMN_ITEM_LOCATION + " = ? AND " +
                        DatabaseHelper.COLUMN_ITEM_QUANTITY + " = ?",
                new String[]{itemName, itemNum, itemLoc, itemQty},
                null, null, null);
        boolean exists = cursor.moveToFirst();
        cursor.close();
        return exists;
    }

    private void registerItem(String itemName, String itemNum, String itemLoc, String itemQty) {
        SQLiteDatabase db = dbHelper2.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_ITEM_NAME, itemName);
        values.put(DatabaseHelper.COLUMN_ITEM_NUMBER, itemNum);
        values.put(DatabaseHelper.COLUMN_ITEM_LOCATION, itemLoc);
        values.put(DatabaseHelper.COLUMN_ITEM_QUANTITY, itemQty);

        long newRowId = db.insert(DatabaseHelper.TABLE_ITEMS, null, values);

        if (newRowId != -1) {
            itemAdded = true;
            Toast.makeText(this, "Item registered successfully.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Error registering item.", Toast.LENGTH_SHORT).show();
        }

        db.close();
    }
}